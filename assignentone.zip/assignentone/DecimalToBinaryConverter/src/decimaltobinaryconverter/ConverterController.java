package decimaltobinaryconverter;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
public class ConverterController{
	private ConverterView theView;
	private ConverterModel theModel;

	public ConverterController(ConverterView theView,ConverterModel theModel){
		this.theView = theView;
		this.theModel = theModel;
		this.theView.addConverterListener(new ConvertListener());
	}
	class ConvertListener implements ActionListener{
		public void actionPerformed(ActionEvent arg0){
			int decimalNum, binary = 0;

			try{
				decimalNum = theView.getDecimalNum();
				

				theModel.convertCurrency(decimalNum);
				theView.setConverted(theModel.getConverterValue());
			}
			catch(NumberFormatException ex){
				theView.displayErrorMessage("enter an integer ");
			}
		}
	}
}