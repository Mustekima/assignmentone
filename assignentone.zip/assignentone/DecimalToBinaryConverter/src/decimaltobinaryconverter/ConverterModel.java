package decimaltobinaryconverter;

public class ConverterModel{
	private int converterValue;
        private int remender;
        private int base = 1;
	public void convertCurrency(int decimalNum ){
            while(decimalNum > 0){remender = decimalNum % 2;
		converterValue = converterValue + remender * base;
                decimalNum = decimalNum / 2;
                base = base * 10;
	}}
	public int getConverterValue(){
		return converterValue;
	}
}	
	
