package decimaltobinaryconverter;

import java.awt.event.ActionListener;
import javax.swing.*;

public class ConverterView extends JFrame{
        private JLabel label = new JLabel(" Decimal To Binary ");
	private JTextField decimalNum = new JTextField(10);
	
	private JButton converterButton = new JButton("Convert");
	private JTextField converted = new JTextField(10);


	ConverterView(){

		JPanel convertPanel = new JPanel();
		this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		this.setSize(500,150);
                convertPanel.add(label);
                
		convertPanel.add(decimalNum);
		
                convertPanel.add(converterButton);
                convertPanel.add(converted);


		this.add(convertPanel);
	}
	public int getDecimalNum(){
		return Integer.parseInt(decimalNum.getText());

	}
	
	public int getConverted(){
		return Integer.parseInt(converted.getText());
		
	}
	public void setConverted(int result){
		converted.setText(Integer.toString(result));
	}

    void addConverterListener(ActionListener listenerForConvertButton){
    	converterButton.addActionListener(listenerForConvertButton);

    }
    void displayErrorMessage(String errorMessage){
	JOptionPane.showMessageDialog(this, errorMessage);
}
}