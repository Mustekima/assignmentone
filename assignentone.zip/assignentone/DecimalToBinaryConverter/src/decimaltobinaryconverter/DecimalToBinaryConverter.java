
package decimaltobinaryconverter;

public class DecimalToBinaryConverter {

   public static void main(String[] args) {
        ConverterView theView = new ConverterView();
        ConverterModel theModel = new ConverterModel();
        ConverterController theController = new ConverterController(theView, theModel);
        theView.setVisible(true);
    
}
}