package prototypestudents;
public class Department extends Student{ 
public Department(){
 type = "Software Engineering"; 
}
 @Override public void draw() {
 System.out.println("Inside Department::draw() method.");
 }
 }