package prototypestudents;
public class IdNo extends Student{ 
public IdNo(){
 type = "ATR/1100/10"; 
}
 @Override public void draw() {
 System.out.println("Inside IdNo::draw() method.");
 }
 }