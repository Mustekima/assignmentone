/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */

package prototypestudents;

/**
 *
 * @author TOSHIBA
 */
public class PrototypeStudents {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        StudentCache.loadCache(); 
        Student clonedStudent = (Student) StudentCache.getStudent("1"); 
        System.out.println("Student1 : " + clonedStudent.getType()); 
        Student clonedStudent2 = (Student) StudentCache.getStudent("2"); 
        System.out.println("Student2 : " + clonedStudent2.getType()); 
        Student clonedStudent3 = (Student) StudentCache.getStudent("3"); 
        System.out.println("Student3 : " + clonedStudent3.getType());
    }
    
}
