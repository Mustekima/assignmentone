package prototypestudents;
public class Student1 extends Student { 
public Student1(){
 type = "Abebe Kebede"; 
}
 @Override public void draw() {
 System.out.println("Inside Student1::draw() method.");
 }
 }