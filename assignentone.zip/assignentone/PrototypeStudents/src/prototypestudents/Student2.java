package prototypestudents;
public class Student2 extends Student { 
public Student2(){
 type = "Amy "; 
}
 @Override public void draw() {
 System.out.println("Inside Student2::draw() method.");
 }
 }