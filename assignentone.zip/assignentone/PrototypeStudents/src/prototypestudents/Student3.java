package prototypestudents;
public class Student3 extends Student { 
public Student3(){
 type = "Ana John"; 
}
 @Override public void draw() {
 System.out.println("Inside Student3::draw() method.");
 }
 }