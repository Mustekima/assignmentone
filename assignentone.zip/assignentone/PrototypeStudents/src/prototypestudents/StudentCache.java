package prototypestudents;
import java.util.Hashtable; 
public class StudentCache {
 private static Hashtable<String, Student> studentMap = new Hashtable<String, Student>(); 
 public static Student getStudent(String studentId) {
  Student cachedStudent = studentMap.get(studentId);
   return (Student) cachedStudent.clone();
    } // for each student run database query and create student // studentMap.put(studentKey, student); // for example, we are adding three students
     public static void loadCache() {
      Student1 student1 = new Student1(); 
      student1.setId("1"); 
      studentMap.put(student1.getId(),student1);
     Student2 student2= new Student2();
     student2.setId("2"); 
     studentMap.put(student2.getId(),student2); 
     Student3 student3 = new Student3(); 
     student3.setId("3"); 
     studentMap.put(student3.getId(),student3);
      }
       }